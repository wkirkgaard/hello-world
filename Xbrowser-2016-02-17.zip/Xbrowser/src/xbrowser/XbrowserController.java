
package xbrowser;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.control.*;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import sun.net.www.http.HttpClient;

/**
 *
 * @author bob
 */
public class XbrowserController implements Initializable {

    private WebEngine xEngine;
    private WebView xBrowser;

    /**
     *
     * @param event
     */
    @FXML
    TextField domainBrowser;
    @FXML
    Button btnURL;
    @FXML
    Button btnRefresh;
    @FXML
    Button btnForward;
    @FXML
    Button btnBack;
    @FXML
    Button btnTabs;
    @FXML
    Button btnMenu;
    @FXML
    Button btnExit;
    @FXML
    WebView dom;

    @FXML
    private void handleButtonClick(ActionEvent event) {

        btnURL.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                try {
                    setWebEngine(navigate(getDomainPath()));
                    domainBrowser.setText(xEngine.getLocation());
                } catch (MalformedURLException ex) {
                    xEngine.load("file:///C:/Users/wil2170824/Desktop/indexError.html");
                }

            }
        });
        btnRefresh.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                xEngine.reload();
                domainBrowser.setText(xEngine.getLocation());
            }
        });
        btnForward.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                xEngine.executeScript("history.forward()");
                domainBrowser.setText(xEngine.getLocation());

            }
        });
        btnBack.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                xEngine.executeScript("history.back()");
                domainBrowser.setText(xEngine.getLocation());
            }
        });
        btnExit.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                System.exit(0);
            }
        });
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadEngine();
        domainBrowser.setText(xEngine.getLocation());
    }

    public void loadEngine() {
        dom.setCursor(Cursor.WAIT);
        xEngine = dom.getEngine();
        xEngine.setJavaScriptEnabled(true);
        xEngine.load("http://www.google.com");
        xEngine.executeScript("window.location;");
        if (xEngine.documentProperty() != null) {
            dom.setCursor(Cursor.DEFAULT);
        } else {
            xEngine.reload();
        }
    }

    public void setWebEngine(URL domain){
        xEngine.load(domain.toString());        
    }

    public String getDomainPath() {
        return domainBrowser.getText();
    }
    public URL navigate(String address) throws MalformedURLException{
        URL url;
        if(address.isEmpty())return null;
        if(!address.startsWith("http://")&&!address.startsWith("https://")) {
            address = "http://" + address;
            try {
                url = new URL(address);
                return url;
            } catch (MalformedURLException ex) {
                xEngine.setUserAgent("Error 404 URL Not Found!");
                xEngine.load("file:///C:/Users/wil2170824/Desktop/indexError.html");
            }
        }
        url = new URL(address);
        return url;
            
        
             
    }
}
